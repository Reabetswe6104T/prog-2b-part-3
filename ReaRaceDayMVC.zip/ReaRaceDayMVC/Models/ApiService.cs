using System.Net.Http.Headers;
using System.Text;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace ReaRaceDayMVC.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ApiService(HttpClient httpClient, IConfiguration configuration,
            IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClient;
            var baseUrl = configuration["ApiSettings:BaseUrl"]
                ?? "https://localhost:7243/api/";
            _httpClient.BaseAddress = new Uri(baseUrl);
            _httpContextAccessor = httpContextAccessor;
        }

        private void AddToken()
        {
            _httpClient.DefaultRequestHeaders.Authorization = null;
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JWToken");
            if (!string.IsNullOrWhiteSpace(token))
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
        }

        public async Task<T?> GetAsync<T>(string endpoint)
        {
            AddToken();
            using var response = await _httpClient.GetAsync(endpoint);
            var body = await response.Content.ReadAsStringAsync();
            if (!response.IsSuccessStatusCode)
                throw new HttpRequestException($"API request failed ({(int)response.StatusCode}): {body}");
            return JsonConvert.DeserializeObject<T>(body);
        }

        public async Task<T?> PostAsync<T>(string endpoint, object data)
        {
            AddToken();
            var json = JsonConvert.SerializeObject(data);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");
            using var response = await _httpClient.PostAsync(endpoint, content);
            var body = await response.Content.ReadAsStringAsync();
            if (!response.IsSuccessStatusCode)
                throw new HttpRequestException($"API request failed ({(int)response.StatusCode}): {body}");
            return JsonConvert.DeserializeObject<T>(body);
        }
    }
}

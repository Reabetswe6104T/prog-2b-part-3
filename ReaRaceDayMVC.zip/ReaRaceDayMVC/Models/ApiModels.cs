using System.ComponentModel.DataAnnotations;

namespace ReaRaceDayMVC.Models
{
    public class LoginViewModel
    {
        [Required, EmailAddress] public string Email { get; set; } = string.Empty;
        [Required, DataType(DataType.Password)] public string Password { get; set; } = string.Empty;
    }

    public class RegisterViewModel
    {
        [Required, EmailAddress] public string Email { get; set; } = string.Empty;
        [Required, MinLength(6), DataType(DataType.Password)] public string Password { get; set; } = string.Empty;
        [Required] public string Role { get; set; } = "Participant";
        public string? FullName { get; set; }
        public string? IDNumber { get; set; }
        public string? PhoneNumber { get; set; }
        public string? OrganisationName { get; set; }
        public string? RegistrationNumber { get; set; }
        public string? ContactPerson { get; set; }
    }

    public class AuthResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public int? UserID { get; set; }
        public string? Email { get; set; }
        public string? Role { get; set; }
        public string? Token { get; set; }
    }

    public class EventViewModel
    {
        public int EventID { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string City { get; set; } = string.Empty;
        public string? Province { get; set; }
        public string? Venue { get; set; }
        public string? EventType { get; set; }
        public string? Description { get; set; }
        public decimal? EntryFee { get; set; }
        public bool IsActive { get; set; }
    }
}

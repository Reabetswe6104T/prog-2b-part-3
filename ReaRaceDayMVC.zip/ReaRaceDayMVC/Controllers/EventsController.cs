using Microsoft.AspNetCore.Mvc;
using ReaRaceDayMVC.Models;
using ReaRaceDayMVC.Services;

namespace ReaRaceDayMVC.Controllers
{
    public class EventsController : Controller
    {
        private readonly ApiService _apiService;
        public EventsController(ApiService apiService) => _apiService = apiService;

        public async Task<IActionResult> Index()
        {
            try
            {
                var events = await _apiService.GetAsync<List<EventViewModel>>("events");
                return View(events ?? new List<EventViewModel>());
            }
            catch
            {
                ViewBag.Error = "Unable to load events. Check that the RaceDay API and database are running.";
                return View(new List<EventViewModel>());
            }
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using ReaRaceDayMVC.Models;
using ReaRaceDayMVC.Services;

namespace ReaRaceDayMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApiService _apiService;
        public AccountController(ApiService apiService) => _apiService = apiService;

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            try
            {
                var response = await _apiService.PostAsync<AuthResponse>(
                    "auth/login", new { model.Email, model.Password });

                if (response == null || !response.Success || string.IsNullOrWhiteSpace(response.Token))
                {
                    ModelState.AddModelError(string.Empty, response?.Message ?? "Login failed. Please try again.");
                    return View(model);
                }

                HttpContext.Session.SetString("JWToken", response.Token);
                HttpContext.Session.SetString("UserRole", response.Role ?? string.Empty);
                HttpContext.Session.SetString("UserEmail", response.Email ?? model.Email);
                HttpContext.Session.SetString("UserID", response.UserID?.ToString() ?? string.Empty);

                return RedirectToAction("Index", "Events");
            }
            catch (HttpRequestException ex)
            {
                ViewBag.Error = ExtractApiMessage(ex.Message);
                return View(model);
            }
            catch (Exception)
            {
                ViewBag.Error = "Could not connect to the RaceDay API. Make sure the API is running.";
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (model.Role == "Participant")
            {
                if (string.IsNullOrWhiteSpace(model.FullName))
                    ModelState.AddModelError(nameof(model.FullName), "Full name is required.");
                if (string.IsNullOrWhiteSpace(model.IDNumber))
                    ModelState.AddModelError(nameof(model.IDNumber), "ID number is required.");
            }
            else if (model.Role == "Organiser")
            {
                if (string.IsNullOrWhiteSpace(model.OrganisationName))
                    ModelState.AddModelError(nameof(model.OrganisationName), "Organisation name is required.");
                if (string.IsNullOrWhiteSpace(model.ContactPerson))
                    ModelState.AddModelError(nameof(model.ContactPerson), "Contact person is required.");
            }
            else
            {
                ModelState.AddModelError(nameof(model.Role), "Choose Participant or Organiser.");
            }

            if (!ModelState.IsValid) return View(model);

            try
            {
                var response = await _apiService.PostAsync<AuthResponse>("auth/register", new
                {
                    model.Email, model.Password, model.Role, model.FullName, model.IDNumber,
                    model.PhoneNumber, model.OrganisationName, model.RegistrationNumber,
                    model.ContactPerson
                });

                if (response?.Success == true)
                {
                    TempData["Success"] = "Your account has been created. Please log in.";
                    return RedirectToAction(nameof(Login));
                }

                ViewBag.Error = response?.Message ?? "Registration failed.";
            }
            catch (HttpRequestException ex)
            {
                ViewBag.Error = ExtractApiMessage(ex.Message);
            }
            catch (Exception)
            {
                ViewBag.Error = "Could not connect to the RaceDay API. Make sure the API is running.";
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        private static string ExtractApiMessage(string message)
        {
            var marker = message.IndexOf('{');
            if (marker >= 0)
            {
                try
                {
                    var parsed = Newtonsoft.Json.Linq.JObject.Parse(message[marker..]);
                    return parsed["message"]?.ToString()
                        ?? parsed["Message"]?.ToString()
                        ?? parsed["error"]?.ToString()
                        ?? "The API rejected the request.";
                }
                catch { }
            }
            return message;
        }
    }
}

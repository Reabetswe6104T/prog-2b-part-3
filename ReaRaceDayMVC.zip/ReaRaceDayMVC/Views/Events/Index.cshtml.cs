﻿namespace ReaRaceDayMVC.Views.Events
{
    public class Index
    {
    }
}

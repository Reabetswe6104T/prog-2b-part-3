using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ReaRaceDayMVC.Views.Display
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

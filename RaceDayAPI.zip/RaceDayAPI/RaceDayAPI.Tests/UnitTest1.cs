using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RaceDayAPI.Data;
using RaceDayAPI.DTOs;
using RaceDayAPI.Services;
using Xunit;

namespace RaceDayAPI.Tests
{
    public class AuthServiceTests
    {
        private RaceDayDbContext GetDb()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            return new RaceDayDbContext(options);
        }

        private IConfiguration GetConfig()
        {
            var settings = new Dictionary<string, string?>
            {
                {"Jwt:Key", "ThisIsATestKeyForJwtTokenGenerationWithEnoughLength123456"},
                {"Jwt:Issuer", "RaceDayAPI"},
                {"Jwt:Audience", "RaceDayClient"}
            };
            return new ConfigurationBuilder().AddInMemoryCollection(settings).Build();
        }

        [Fact]
        public async Task Register_Participant_Success()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            var result = await service.RegisterAsync(new RegisterDTO
            {
                Email = "test@test.com",
                Password = "Password123",
                Role = "Participant",
                FullName = "Test User",
                IDNumber = "9001011234567",
                Gender = "Female"
            });
            result.Success.Should().BeTrue();
            result.Role.Should().Be("Participant");
            result.Token.Should().NotBeNullOrEmpty();
        }

        [Fact]
        public async Task Register_Organiser_Success()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            var result = await service.RegisterAsync(new RegisterDTO
            {
                Email = "org@test.com",
                Password = "Password123",
                Role = "Organiser",
                OrganisationName = "Test Org",
                ContactPerson = "Person",
                RegistrationNumber = "REG001"
            });
            result.Success.Should().BeTrue();
            result.Role.Should().Be("Organiser");
        }

        [Fact]
        public async Task Register_Duplicate_Email_Fails()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            await service.RegisterAsync(new RegisterDTO { Email = "dup@test.com", Password = "Password123", Role = "Participant", FullName = "A", IDNumber = "9001011234567" });
            var result = await service.RegisterAsync(new RegisterDTO { Email = "dup@test.com", Password = "Password456", Role = "Participant", FullName = "B", IDNumber = "9001011234568" });
            result.Success.Should().BeFalse();
        }

        [Fact]
        public async Task Register_Invalid_Role_Fails()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            var result = await service.RegisterAsync(new RegisterDTO
            {
                Email = "bad@test.com",
                Password = "Password123",
                Role = "Admin",
                FullName = "Test",
                IDNumber = "9001011234567"
            });
            result.Success.Should().BeFalse();
        }

        [Fact]
        public async Task Login_Valid_Credentials_Success()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            await service.RegisterAsync(new RegisterDTO { Email = "login@test.com", Password = "Password123", Role = "Participant", FullName = "Test", IDNumber = "9001011234567" });
            var result = await service.LoginAsync(new LoginDTO { Email = "login@test.com", Password = "Password123" });
            result.Success.Should().BeTrue();
            result.Token.Should().NotBeNullOrEmpty();
        }

        [Fact]
        public async Task Login_Wrong_Password_Fails()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            await service.RegisterAsync(new RegisterDTO { Email = "wrong@test.com", Password = "Correct123", Role = "Participant", FullName = "Test", IDNumber = "9001011234567" });
            var result = await service.LoginAsync(new LoginDTO { Email = "wrong@test.com", Password = "Wrong123" });
            result.Success.Should().BeFalse();
        }

        [Fact]
        public async Task Login_Nonexistent_Email_Fails()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            var result = await service.LoginAsync(new LoginDTO { Email = "nobody@test.com", Password = "Password123" });
            result.Success.Should().BeFalse();
        }

        [Fact]
        public async Task Register_Password_Is_Hashed()
        {
            var db = GetDb();
            var service = new AuthService(db, GetConfig());
            await service.RegisterAsync(new RegisterDTO { Email = "hash@test.com", Password = "MyPassword123", Role = "Participant", FullName = "Test", IDNumber = "9001011234567" });
            var user = await db.Users.FirstAsync(u => u.Email == "hash@test.com");
            user.PasswordHash.Should().NotBe("MyPassword123");
            user.PasswordHash.Should().StartWith("$2");
        }
    }
}